import pandas as pd
import torch
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
import sys
import os
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
import random
from deepfm_frnet import deepfm


def get_auc(loader, model):
    pred, target = [], []
    model.eval()
    with torch.no_grad():
        for x, y in loader:
            x = x.float()
            y = y.float()
            y_hat = model(x)
            pred += list(y_hat.numpy())
            target += list(y.numpy())
    auc = roc_auc_score(target, pred)
    return auc


if __name__=="__main__":

    batch_size = 500
    lr = 1e-3
    wd = 1e-5
    epoches = 40
    seed = 2022
    embedding_size = 10
    # device = 'cuda:0'
    # pd.set_option('display.max_rows', None)  # 显示数据中所有的列
    data = pd.read_csv('vehicle_data_model_50w_3.csv')
    print(data['label'].value_counts())
    dense_feature = ['driver_auth_success_days', 'cargo_search_cnt_3', 'cargo_search_cnt_7', 'scan_cargo_cnt_3',
                     'scan_cargo_cnt_7', 'click_cargo_cnt_3_x', 'click_cargo_cnt_7', 'call_cnt_3_driver',
                     'call_cnt_7_driver',
                     'shipper_auth_success_days', 'exposure_cargo_cnt_3', 'exposure_cnt_3', 'click_cargo_cnt_3_y',
                     'click_cnt_3', 'cargo_weight', 'vector_regular_subscribe_line',
                     'vector_regular_cargo_line_all', 'vector_regular_cargo_truck_type_all',
                     'vector_regular_cargo_truck_length_all', 'vector_regular_cargo_line_30',
                     'vector_regular_cargo_truck_type_30', 'vector_regular_cargo_truck_length_30']

    # 假设你的数据集中包含'label'列，并且dense_feature已经定义
    sparse_feature = data.drop(columns=['label'] + dense_feature).columns.tolist()
    print(len(sparse_feature))
    pd.options.display.max_rows = None  # 显示所有列
    data[sparse_feature] = data[sparse_feature].astype('uint8')
    target = ['label']

    feat_sizes = {}
    feat_sizes_dense = {feat: 1 for feat in dense_feature}
    feat_sizes_sparse = {feat: len(data[feat].unique()) for feat in sparse_feature}
    feat_sizes.update(feat_sizes_dense)
    feat_sizes.update(feat_sizes_sparse)

    fixlen_feature_columns = [(feat, 'sparse') for feat in sparse_feature] + [(feat, 'dense') for feat in dense_feature]
    dnn_feature_columns = fixlen_feature_columns
    linear_feature_columns = fixlen_feature_columns

    # train, test = train_test_split(data, test_size=0.2, random_state=seed)



    # 数据集划分
    train, test = train_test_split(data, test_size=0.2, random_state=seed)
    validation, test = train_test_split(test, test_size=0.5, random_state=seed)

    # 计算每个数据集中 0 和 1 标签的数量
    train_label_summary = train['label'].value_counts()
    validation_label_summary = validation['label'].value_counts()
    test_label_summary = test['label'].value_counts()

    # 输出结果
    print("训练集标签汇总:\n", train_label_summary)
    print("验证集标签汇总:\n", validation_label_summary)
    print("测试集标签汇总:\n", test_label_summary)


    # DataLoader准备
    def create_data_loader(df, batch_size):
        labels = pd.DataFrame(df['label'])
        features = df.drop(columns=['label'])
        tensor_data = TensorDataset(torch.from_numpy(np.array(features)), torch.from_numpy(np.array(labels)))
        return DataLoader(tensor_data, shuffle=True, batch_size=batch_size)


    train_loader = create_data_loader(train, batch_size)
    validation_loader = create_data_loader(validation, batch_size)
    test_loader = create_data_loader(test, batch_size)

    # 模型初始化
    # model = FiBiNET(feat_sizes, embedding_size, linear_feature_columns, dnn_feature_columns)
    device = 'cpu'
    model = deepfm(feat_sizes, sparse_feature_columns=sparse_feature, dense_feature_columns=dense_feature,
                   dnn_hidden_units=[256, 128], dnn_dropout=0.5, ebedding_size=10,
                   l2_reg_linear=1e-3, device=device)
    loss_func = nn.BCELoss(reduction='mean')
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=wd)
    # 早停策略参数
    early_stopping_threshold = 0.796
    best_validation_auc = 0


    # 定义一个函数来计算给定数据加载器上的平均损失和AUC
    def evaluate(loader):
        model.eval()
        total_loss = 0.0
        total_samples = 0
        with torch.no_grad():
            for x, y in loader:
                x, y = x.float(), y.float()
                y_hat = model(x)
                loss = loss_func(y_hat, y)
                total_loss += loss.item() * x.size(0)
                total_samples += x.size(0)
        avg_loss = total_loss / total_samples
        auc = get_auc(loader, model)
        return avg_loss, auc


    # 训练循环
    for epoch in range(epoches):
        total_loss_epoch = 0.0
        total_tmp = 0
        model.train()
        for index, (x, y) in enumerate(train_loader):
            x, y = x.float(), y.float()
            y_hat = model(x)

            optimizer.zero_grad()
            loss = loss_func(y_hat, y)
            loss.backward()
            optimizer.step()
            total_loss_epoch += loss.item()
            total_tmp += 1

        # 验证集评估
        validation_loss, validation_auc = evaluate(validation_loader)
        print(
            f'Epoch {epoch}/{epoches}, Train Loss: {total_loss_epoch / total_tmp:.4f}, Validation_loss: {validation_loss:.4f},Validation AUC: {validation_auc:.4f}')

        # 更新最佳验证集AUC
        if validation_auc > best_validation_auc:
            best_validation_auc = validation_auc

        # 早停判断
        if validation_auc >= early_stopping_threshold:
            print(f'Early stopping triggered at epoch {epoch}, Validation AUC: {validation_auc:.4f}')
            break

    # 测试集评估
    test_loss, final_test_auc = evaluate(test_loader)
    print(f'Test_loss:{test_loss:.4f},Final Test AUC: {final_test_auc:.4f}')